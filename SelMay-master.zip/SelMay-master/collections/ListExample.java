package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		List<String> tamil = new LinkedList<String>();
		tamil.add("Theri");
		tamil.add("KAALA");
		tamil.add("Robo2");
		tamil.add("Veeram");
		tamil.add("Robo2");
		System.out.println(tamil);
		System.out.println("************");
		Collections.sort(tamil);		
		System.out.println(tamil);
		
		
		
		
		/*tamil.remove("Robo2");
		System.out.println(tamil.contains("kaala"));
		//tamil.clear();
		System.out.println(tamil+" "+tamil.isEmpty());
		//System.out.println(tamil.size());
		//System.out.println(tamil.get(1));
	*/
				
				
				
				
				
				
				
				
				
	}

	
	
	
	
	
	
	
	
}
