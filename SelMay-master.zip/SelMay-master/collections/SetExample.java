package collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {

	public static void main(String[] args) {
		Set<Integer> employeeID = new HashSet<Integer>();
		employeeID.add(2235);
		employeeID.add(2235);
		employeeID.add(1234);
		employeeID.add(1235);
		employeeID.add(12355);
		employeeID.add(1236);
		System.out.println(employeeID);
		
				
				
		
		
		
		
		
		
	}

	
	
	
	
	
	
	
	
}
