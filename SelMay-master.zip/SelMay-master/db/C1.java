package db;

public class C1 {
	
	public C1() {
		
	}
	
	public void m1() {
		
	}

}
