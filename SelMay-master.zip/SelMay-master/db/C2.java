package db;

public class C2 extends C1{
	public C2() {
		super();
	}
	public C2(String name) {
		super();
	}
	
	public void m1() {

	}
	public void m2() {
		super.m1();
	}

}
