package string;

public class LearnStringFun {

	public static void main(String[] args) {
		
		String txt = "Success";
		
		
		/*String txt = " Hello India ";
		String txt1 = " India";
		String replaceAll = txt.replaceAll("Hello", "Welcome");
		System.out.println(replaceAll);		
		String[] split = txt.trim().split("");
		//System.out.println(split[1]);
		for (String string : split) {
			System.out.println(string);
		}
		int length = txt.length();
		//char[] allChar = txt.toCharArray();
		//System.out.println(txt.trim());
		for (int i = 0; i < length; i++) {
			System.out.println(txt.charAt(i));
		}
		char charAt = txt.charAt(length);
		System.out.println(charAt);
		
		int indexOf = txt.indexOf('l');
		System.out.println(indexOf);
		int lastIndexOf = txt.lastIndexOf('h');
		System.out.println(lastIndexOf);
		String concat = txt.concat(txt1);
		System.out.println(concat);
		System.out.println(concat.substring(6,9));
	
		int firstIndex = txt.indexOf('l');
		String substring = txt.substring(firstIndex+1);
		System.out.println(substring);
		int indexOf = substring.indexOf('l');
		System.out.println(indexOf);
		System.out.println(firstIndex+indexOf+1);
			
		int j = 0;
		for (int i = 0; i < txt.length(); i++) {
			if (txt.charAt(i)=='l') {
				j++;
				if (j==2) {
					System.out.println(i);					
				}
			}
		}
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
